/*
* Author: Christopher Ellison
*
* Date: Oct 16 2026
*
*CS305 Project 2
*
*/

package com.snhu.sslserver;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

@SpringBootApplication
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
}

@RestController
class ServerController {

    // Add route to return and verify a checksum
    @RequestMapping("/hash")
    public String myHash() throws Exception {

        // String for name and custom data String
        String name = "Christopher Ellison";
    	String data = "Artemis Financial Project 2026";

        // Declaring the SHA-256 hashing algorithm as a string
        String algorithm = "SHA-256";

        // Create a MessageDigest object using the declared algorithm
        MessageDigest md = MessageDigest.getInstance(algorithm);

        // Generate the hash value from the data String
        byte[] hash = md.digest(data.getBytes(StandardCharsets.UTF_8));

        // Convert the hash to hexadecimal
        String checksum = bytesToHex(hash);

        // Verify the checksum by generating it again
        MessageDigest verifyMd = MessageDigest.getInstance(algorithm);
        byte[] verifyHash = verifyMd.digest(
                data.getBytes(StandardCharsets.UTF_8));
        String verificationChecksum = bytesToHex(verifyHash);

        boolean verified = MessageDigest.isEqual(hash, verifyHash);

        // Return the information created
        return "<p>Name: " + name + "</p>"
                + "<p>Statement: " + data + "</p>"
                + "<p>This is the Cipher Algorithm Chosen: "
                + algorithm + "</p>"
                + "<p>Checksum Value Generated: " + checksum + "</p>"
                + "<p>Checksum Verification Value: "
                + verificationChecksum + "</p>"
                + "<p>Verification Result: "
                + (verified ? "SUCCESS - Checksums Match"
                            : "FAILED - Checksums Do Not Match")
                + "</p>";
    }

    // Converts the byte array into a hexadecimal string
    private static String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();

        // Adds the formatted hexadecimal value to StringBuilder
        for (byte b : bytes) {
            hexString.append(String.format("%02x", b));
        }

        return hexString.toString();
    }
}